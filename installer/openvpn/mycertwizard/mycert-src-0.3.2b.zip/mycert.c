/*
 *  My Certificate Wizard
 *
 *  Copyright (C) 2004 Vlada Macek <mycert@seznam.cz>
 *
 ** $Id: mycert.c,v 1.12 2004/11/17 19:37:03 tuttle Exp $ **
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <windows.h>
#include <stdio.h>
#include <shlobj.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "mycert-res.h"
#include "mycert.h"


GLOBALS globals;

void SetDNFromConfig(HWND h)
{
	char value[MAXLINELEN+1];

	GetPrivateProfileString("dn", "C", "", value, sizeof(value), globals.MyConfig);
	value[2] = '\0';
	SetDlgItemText(h, IN_COUNTRY, value);
	GetPrivateProfileString("dn", "ST", "", value, sizeof(value), globals.MyConfig);
	value[MAXLINELEN] = '\0';
	SetDlgItemText(h, IN_STATE, value);
	GetPrivateProfileString("dn", "L", "", value, sizeof(value), globals.MyConfig);
	value[MAXLINELEN] = '\0';
	SetDlgItemText(h, IN_LOCALITY, value);
	GetPrivateProfileString("dn", "O", "", value, sizeof(value), globals.MyConfig);
	value[MAXLINELEN] = '\0';
	SetDlgItemText(h, IN_ORGANIZATION, value);
	GetPrivateProfileString("dn", "OU", "", value, sizeof(value), globals.MyConfig);
	value[MAXLINELEN] = '\0';
	SetDlgItemText(h, IN_ORGUNIT, value);
	GetPrivateProfileString("dn", "CN", "", value, sizeof(value), globals.MyConfig);
	value[MAXLINELEN] = '\0';
	if (value[0]) SetDlgItemText(h, IN_COMMONNAME, value);
	GetPrivateProfileString("dn", "emailAddress", "", value, sizeof(value), globals.MyConfig);
	value[MAXLINELEN] = '\0';
	if (value[0]) SetDlgItemText(h, IN_EMAIL, value);

	if (GetPrivateProfileInt("dn", "C_allow", 1, globals.MyConfig) != 1)
		EnableWindow(GetDlgItem(h, IN_COUNTRY), FALSE);
	if (GetPrivateProfileInt("dn", "ST_allow", 1, globals.MyConfig) != 1)
		EnableWindow(GetDlgItem(h, IN_STATE), FALSE);
	if (GetPrivateProfileInt("dn", "L_allow", 1, globals.MyConfig) != 1)
		EnableWindow(GetDlgItem(h, IN_LOCALITY), FALSE);
	if (GetPrivateProfileInt("dn", "O_allow", 1, globals.MyConfig) != 1)
		EnableWindow(GetDlgItem(h, IN_ORGANIZATION), FALSE);
	if (GetPrivateProfileInt("dn", "OU_allow", 1, globals.MyConfig) != 1)
		EnableWindow(GetDlgItem(h, IN_ORGUNIT), FALSE);
}

BOOL outdir_okay(char *dirpath)
{
	struct stat st;

	if (!dirpath[0]) return FALSE;

	if ((stat(dirpath, &st) != 0) || (!S_ISDIR(st.st_mode))) return FALSE;

	if (access(dirpath, W_OK) != 0) return FALSE;

	return TRUE;
}

void SetOutputFolder(HWND h)
{
	char value[MAX_PATH+1], *p;

	GetPrivateProfileString("paths", "dir", "", value, sizeof(value), globals.MyConfig);
	value[MAX_PATH] = '\0';

	while ((p = strrchr(value, '\\')) && (*(p+1) == '\0')) *p = '\0';	// strip tail backslashes
	if (!outdir_okay(value)) {

/*		# Alternative way of setting the output folder.
		# Value of regdir= should be read in case dir= is not specified.
		# (FEATURE NOT IMPLEMENTED!)
		# regdir=HKLM\SOFTWARE\OpenVPN\config
*/
		strLcpy(value, "C:\\");		// final default value
	}

	SetDlgItemText(h, TEXT_FOLDER, value);
}

BOOL PreparePaths(char *CN)
{
	int zero = 0;

	SetFocus(GetDlgItem(globals.myH, IN_COMMONNAME));

	GetDlgItemText(globals.myH, IN_COMMONNAME, CN, MAXLINELEN);
	if (!CN[0]) {
		MsgBox(_("Input Error", 0), MB_OK | MB_ICONSTOP, _("Common Name must not be blank!", 1));
		return FALSE;
	}
	safe_string(CN);

	GetDlgItemText(globals.myH, TEXT_FOLDER, globals.OutFolder, sizeof(globals.OutFolder));

	GetPrivateProfileString("extensions", "key", KEY_EXT, globals.KeyExt, sizeof(globals.KeyExt), globals.MyConfig);
	sLprintf(globals.KeyFilePath, "%s\\%s.%s", globals.OutFolder, CN, globals.KeyExt);

	GetPrivateProfileString("extensions", "req", REQ_EXT, globals.ReqExt, sizeof(globals.ReqExt), globals.MyConfig);
	sLprintf(globals.OutFilePath, "%s\\%s.%s", globals.OutFolder, CN, globals.ReqExt);

	GetPrivateProfileString("extensions", "cert", CERT_EXT, globals.CertExt, sizeof(globals.CertExt), globals.MyConfig);
	sLprintf(globals.CertFilePath, "%s\\%s.%s", globals.OutFolder, CN, globals.CertExt);

	if (access(globals.KeyFilePath, R_OK) == 0) zero++;
	if (access(globals.OutFilePath, R_OK) == 0) zero++;

	if (globals.OVPNTemplate[0]) {
		GetPrivateProfileString("extensions", "ovpn", OVPN_EXT, globals.OvpnExt, sizeof(globals.OvpnExt), globals.MyConfig);
		sLprintf(globals.OVPNFilePath, "%s\\%s.%s", globals.OutFolder, CN, globals.OvpnExt);
		if (access(globals.OVPNFilePath, R_OK) == 0) zero++;
	}

	if (zero && (MsgBox(_("Confirmation", 0), MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2,
		_("Some files named %s.* already exist in the output folder! Once they are lost, it may be hard to get them back.\nAre you sure to OVERWRITE them?", 1), CN) != IDYES)) return FALSE;

	return TRUE;
}

BOOL CheckPassphrase(char *outpass)
{
	if (!globals.cfg_nodes) {
		char pass2[MAXLINELEN+1];
		unsigned int minpass = Atoi(CfgGetValue("minpass"));

		SetFocus(GetDlgItem(globals.myH, IN_PASS));

		GetDlgItemText(globals.myH, IN_PASS, outpass, MAXLINELEN);
		GetDlgItemText(globals.myH, IN_PASS2, pass2, sizeof(pass2));

		if (strcmp(outpass, pass2)) {
			MsgBox(_("Input Error", 0), MB_OK | MB_ICONSTOP, _("Your two passphrases do not match!", 1));
			return FALSE;
		}

		if (minpass > 0) {
			if (strlen(outpass) < minpass) {
				MsgBox(_("Security Restriction", 0), MB_OK | MB_ICONSTOP, _("Your passphrase must be at least %d characters long. %d is not enough!", 1), minpass, strlen(outpass));
				return FALSE;
			}
		} else if (!outpass[0]) {
			if (MsgBox(_("Security Warning", 0), MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2,
				_("Warning: You've entered no passphrase. Do you really want to leave your private key UNENCRYPTED?", 1))
				!= IDYES) return FALSE;
		} else if (strlen(outpass) < MINPASSLEN) {
			if (MsgBox(_("Security Warning", 0), MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2,
				_("Your passphrase is really short (under %d characters). Are you sure to use such weak protection?", 1), MINPASSLEN)
				!= IDYES) return FALSE;
		}
	}

	return TRUE;
}

#ifdef REGULAR_EXPRESSIONS

BOOL check_field(int field, const char *re_opt)
{
	char rexpr[MAXLINELEN+1];
	
	if (IsWindowEnabled(GetDlgItem(globals.myH, field))) {

		GetPrivateProfileString("dn", re_opt, "", rexpr, sizeof(rexpr), globals.MyConfig);
		rexpr[MAXLINELEN] = '\0';
		GetDlgItemText(globals.myH, field, globals.msgbuf, sizeof(globals.msgbuf));
	
#ifdef DEBUG
		printf("rexpr=%s\nstr=%s\n", rexpr, globals.msgbuf);
		fflush(stdout);
#endif

		if (!RegExpMatch(rexpr, globals.msgbuf)) {
			SetFocus(GetDlgItem(globals.myH, field));
			return FALSE;
		}

	}
	
	return TRUE;
}

#endif /* REGULAR_EXPRESSIONS */

BOOL MainProcessing(void)
{
	HWND waitDlg;
	char outpass[MAXLINELEN+1] = "";
	char CN[MAXLINELEN+1];
	BOOL ovpnok = FALSE;

#ifdef REGULAR_EXPRESSIONS

	if(!check_field(IN_COMMONNAME,	"CN_re")
	|| !check_field(IN_EMAIL,		"email_re")
	|| !check_field(IN_COUNTRY,		"C_re")
	|| !check_field(IN_STATE,		"ST_re")
	|| !check_field(IN_LOCALITY,	"L_re")
	|| !check_field(IN_ORGANIZATION,"O_re")
	|| !check_field(IN_ORGUNIT,		"OU_re"))
		return FALSE;

#endif /* REGULAR_EXPRESSIONS */

	if (!CheckPassphrase(outpass)) return FALSE;

	if (!PreparePaths(CN)) return FALSE;

	waitDlg = CreateDialog(globals.myI, (LPCTSTR)DLG_PLSWAIT, globals.myH, NULL);
	CustomizeWaitDialog(waitDlg);
	ShowWindow(waitDlg, SW_SHOW);

	globals.opensslerr = CreateRequest(globals.KeyFilePath, globals.OutFilePath, globals.cfg_nodes, outpass);

#ifdef DEBUG
	printf("createrequest() result: %s\n", globals.opensslerr ? globals.opensslerr : "(null)");
	fflush(stdout);
#endif

	DestroyWindow(waitDlg);

	DestroyBillGatesEmpire();

	if (globals.opensslerr == NULL) {
		if (globals.OVPNTemplate[0])
			ovpnok = ProcessOVPNTemplate();
	} else {
		MsgBox(_("OpenSSL Error", 1), MB_OK | MB_ICONSTOP, globals.opensslerr);
		return FALSE;
	}

	if (ovpnok)
		sLprintf(globals.msgbuf, _("- %s.%s (Private key)\n- %s.%s (Certificate request)\n- %s.%s (OpenVPN configuration)", 0),
			CN, globals.KeyExt, CN, globals.ReqExt, CN, globals.OvpnExt);
	else
		sLprintf(globals.msgbuf, _("- %s.%s (Private key)\n- %s.%s (Certificate request)", 0),
			CN, globals.KeyExt, CN, globals.ReqExt);

	/* try to copy additional files */
	CopyExtraFiles();

	return TRUE;
}

BOOL CALLBACK MYCERTDialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam __attribute__((unused)))
{
  HICON hIcon;

  switch (msg) {

    case WM_INITDIALOG:
	globals.myH = hwndDlg;
	
	CustomizeMainDialog(hwndDlg);

	hIcon = (HICON)LoadImage(GetModuleHandle(NULL),
		MAKEINTRESOURCE(APP_ICON), IMAGE_ICON, 0, 0, LR_DEFAULTCOLOR);
	if (hIcon) {
		SendMessage(hwndDlg, WM_SETICON, (WPARAM) (ICON_SMALL), (LPARAM) (hIcon));
		SendMessage(hwndDlg, WM_SETICON, (WPARAM) (ICON_BIG), (LPARAM) (hIcon));
	}

	sLprintf(globals.msgbuf, _("Version %s", 0), VERSION);
	SetDlgItemText(hwndDlg, TEXT_VERSION, globals.msgbuf);

	SendMessage(GetDlgItem(hwndDlg, IDABOUTBUT), BM_SETIMAGE, (WPARAM) IMAGE_ICON, (LPARAM) hIcon);

	SendMessage(GetDlgItem(hwndDlg, IN_COUNTRY), EM_SETLIMITTEXT, 2, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_STATE), EM_SETLIMITTEXT, MAXLINELEN, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_LOCALITY), EM_SETLIMITTEXT, MAXLINELEN, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_ORGANIZATION), EM_SETLIMITTEXT, MAXLINELEN, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_ORGUNIT), EM_SETLIMITTEXT, MAXLINELEN, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_COMMONNAME), EM_SETLIMITTEXT, MAXLINELEN, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_EMAIL), EM_SETLIMITTEXT, MAXLINELEN, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_PASS), EM_SETLIMITTEXT, MAXLINELEN, 0);
	SendMessage(GetDlgItem(hwndDlg, IN_PASS2), EM_SETLIMITTEXT, MAXLINELEN, 0);

	SetDNFromConfig(hwndDlg);

	SetOutputFolder(hwndDlg);

	globals.cfg_nodes = (Atoi(CfgGetValue("nodes")) != 0) ? TRUE : FALSE;

	if (globals.cfg_nodes) {
		EnableWindow(GetDlgItem(hwndDlg, IN_PASS), FALSE);
		EnableWindow(GetDlgItem(hwndDlg, IN_PASS2), FALSE);
	}

	return TRUE;

    case WM_COMMAND:
      switch (LOWORD(wParam)) {
        case IDOK:
        
		if (MainProcessing() == TRUE) {
			/* The donedialog uses global.msgbuf set at the end of MainProcessing(). */
			DialogBox(globals.myI, (LPCTSTR)DLG_DONE, hwndDlg, (DLGPROC)DONEDialogFunc);
			EndDialog(hwndDlg, LOWORD(wParam));
		}
		return TRUE;

        case IDCANCEL:
		EndDialog(hwndDlg, LOWORD(wParam));
		return TRUE;

	case IDHELPBUT:
		return TRUE;

	case IDABOUTBUT:
		sLprintf(globals.msgbuf, _(ABOUTTEXT, 0), VERSION);
		MessageBox(hwndDlg, globals.msgbuf, _("About", 0), MB_OK);
		return TRUE;

	case IDCHGFOLDER:
	    {
		TCHAR selfolder[MAX_PATH+1];

		GetDlgItemText(hwndDlg, TEXT_FOLDER, selfolder, sizeof(selfolder));
		if (ChooseFolder(hwndDlg, selfolder))
			SetDlgItemText(hwndDlg, TEXT_FOLDER, selfolder);

		return TRUE;
	    }
      }
      break;
    case WM_CLOSE:
	EndDialog(hwndDlg, LOWORD(wParam));
      return TRUE;
     
  }
  return FALSE;
}

static void ChangeToExeDir(void)
{
	char buffer[MAX_PATH+1], *p;

	GetModuleFileName(NULL, buffer, sizeof(buffer));
	p = strrchr(buffer, '\\');
	if (p) {
		*p = '\0';
		chdir(buffer);
	}
}

void ShowManifesto(void)
{
	char *p;

	GetPrivateProfileString("strings", "manifesto", "", globals.msgbuf, sizeof(globals.msgbuf)-1, globals.MyConfig);
	if (globals.msgbuf[0] == '\0')
		return;

	for (p=globals.msgbuf; *p; p++)
		if (*p == '^') *p = '\n';

	MessageBox(globals.myH, globals.msgbuf, _("Welcome", 0), MB_OK);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance __attribute__((unused)), PSTR szCmdLine, int iCmdShow __attribute__((unused))) 
{
	memset(&globals, 0, sizeof(globals));
	globals.myH = HWND_DESKTOP;
	globals.myI = hInstance;

	ResolveConfigFilename(szCmdLine);

	ChangeToExeDir();

	/* Some prelim checking that the admin may consider handy. */

	if (!Atoi(CfgGetValue("pubkey")) && Atoi(CfgGetValue("norequest")))
		MsgBox(_("Configuration Glitch", 0), MB_OK | MB_ICONWARNING,
			_("The INI file disables creating both the certificate request and the public key. So no reasonable output will be given.\nThis is probably not what you want.", 1));

	GetPrivateProfileString("openvpn", "template", "", globals.OVPNTemplate, sizeof(globals.OVPNTemplate), globals.MyConfig);

	if (globals.OVPNTemplate[0] && (access(globals.OVPNTemplate, R_OK) != 0)) {
		MsgBox(_("Configuration Error", 0), MB_OK | MB_ICONWARNING, _("Error finding OpenVPN input template file: %s\nNo OpenVPN configuration could be created.", 1), globals.OVPNTemplate);
		globals.OVPNTemplate[0] = '\0';
	}

	ShowManifesto();

	/* Let's run! */

	if (DialogBox(hInstance, (LPCTSTR)DLG_MYCERT, HWND_DESKTOP, (DLGPROC)MYCERTDialogFunc) <= 0)
		ErrorExit("main dialogbox");

	return 0;
}

