/*
 *  My Certificate Wizard
 *
 *  Copyright (C) 2004 Vlada Macek <mycert@seznam.cz>
 *
 ** $Id: request.c,v 1.8 2004/11/17 19:37:03 tuttle Exp $ **
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/* Rewritten apps/req.c source file from the openssl package.
 * Copyright (C) 1995-1998 Eric Young (eay@cryptsoft.com)
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include <windows.h>

#include <openssl/bio.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/pem.h>

#include "mycert-res.h"
#include "mycert.h"

#define DEFAULT_KEY_LENGTH	1024
#define MIN_KEY_LENGTH		384

static int make_REQ(X509_REQ *req,EVP_PKEY *pkey);
static int Str2fmt(const char *s);

#define TYPE_RSA	1
#define TYPE_DSA	2
#define TYPE_DH		3

#define FORMAT_UNDEF    0
#define FORMAT_ASN1     1
#define FORMAT_TEXT     2
#define FORMAT_PEM      3
#define FORMAT_NETSCAPE 4
#define FORMAT_PKCS12   5
#define FORMAT_SMIME    6
#define FORMAT_ENGINE   7
#define FORMAT_IISSGC	8	/* XXX this stupid macro helps us to avoid
				 * adding yet another param to load_*key() */

const char *CreateRequest(const char *keyout, const char *outfile, int nodes, const char *passout)
{
#ifndef OPENSSL_NO_DSA
	DSA *dsa_params=NULL;
#endif
	X509_REQ *req=NULL;
	EVP_PKEY *pkey=NULL;
	int i=0, pkey_type = TYPE_RSA;
	long newkey = -1;
	BIO *out = NULL;
	int outformat, keyform, noout = 0;
	int kludge = 0, pubkey = 0;
	char const *exitstr = NULL, *p;
	const EVP_CIPHER *cipher = NULL;
/*DELRAND	char *inrand=NULL;*/
	const EVP_MD *md_alg=NULL,*digest=EVP_sha1();

#ifndef OPENSSL_NO_DES
	cipher = EVP_des_ede3_cbc();
#endif

	ERR_load_crypto_strings();
	OpenSSL_add_all_algorithms();
	
	outformat = Str2fmt(CfgGetValue("outformat"));
	pubkey = Atoi(CfgGetValue("pubkey"));
	noout = Atoi(CfgGetValue("norequest"));
	keyform = Str2fmt(CfgGetValue("keyformat"));
#ifdef DEBUG
	printf("keyform=%d, outform=%d\n", keyform, outformat);
	fflush(stdout);
#endif

	if (keyout == NULL) return "Keyout argument is NULL.";
	if (outfile == NULL) return "Outfile argument is NULL.";

	kludge= Atoi(CfgGetValue("asn1kludge"));
	if ((p = CfgGetValue("digest")) && (p[0] != '\0')) {
		md_alg = EVP_get_digestbyname(p);
		if (md_alg != NULL) digest = md_alg;
		else return _("Unknown digest name.", 0);
	}
			
	if (!passout || !passout[0]) nodes = 1;

	p = CfgGetValue("keytype");
	if (p) {
		int is_numeric;

		is_numeric = p[0] >= '0' && p[0] <= '9';
		if (strncmp("rsa:",p,4) == 0 || is_numeric) {
			pkey_type=TYPE_RSA;
			if(!is_numeric) p+=4;
			newkey= atoi(p);
		} else
#ifndef OPENSSL_NO_DSA
		if (strncmp("dsa:",p,4) == 0) {
			X509 *xtmp=NULL;
			EVP_PKEY *dtmp;
			BIO *in=NULL;

			pkey_type=TYPE_DSA;
			p+=4;
			if ((in=BIO_new_file(p,"r")) == NULL) {
				exitstr = _("Could not read specified parameter file.", 0);
				goto end;
			}
			if ((dsa_params=PEM_read_bio_DSAparams(in,NULL,NULL,NULL)) == NULL) {
				ERR_clear_error();
				(void)BIO_reset(in);
				if ((xtmp=PEM_read_bio_X509(in,NULL,NULL,NULL)) == NULL) {
					exitstr = _("Unable to load DSA parameters from file.", 0);
					goto end;
				}

				if ((dtmp=X509_get_pubkey(xtmp)) == NULL) {
					exitstr = _("Could not get the public key.", 0);
					goto end;
				}
				if (dtmp->type == EVP_PKEY_DSA)
					dsa_params=DSAparams_dup(dtmp->pkey.dsa);
				EVP_PKEY_free(dtmp);
				X509_free(xtmp);
				if (dsa_params == NULL) {
					exitstr = _("Certificate does not contain DSA parameters.", 0);
					goto end;
				}
			}
			BIO_free(in);
			newkey=BN_num_bits(dsa_params->p);
			in=NULL;
		} else 
#endif
#ifndef OPENSSL_NO_DH
			if (strncmp("dh:",p,4) == 0) {
				pkey_type=TYPE_DH;
				p+=3;
			}
		else
#endif
			pkey_type=TYPE_RSA;
	}

/*DELRAND if (strcmp(*argv,"-rand") == 0)
	{
		if (--argc < 1) goto bad;
		inrand= *(++argv);
	}
*/

	///twice? ERR_load_crypto_strings();

	out=BIO_new(BIO_s_file());
	if (out == NULL) {
		exitstr = _("Could not initialize output file.", 0);
		goto end;
	}

/*DELRAND char *randfile = NCONF_get_string(req_conf,SECTION,"randfile");
	if (randfile == NULL)
		ERR_clear_error();
	app_RAND_load_file(randfile, bio_err, 0);
	if (inrand)
		app_RAND_load_files(inrand);
*/	
	if (newkey <= 0) newkey = DEFAULT_KEY_LENGTH;

	if (newkey < MIN_KEY_LENGTH) {
		exitstr = _("Private key is too short.", 0);
		goto end;
	}

	if ((pkey = EVP_PKEY_new()) == NULL) {
		exitstr = _("Could not allocate the private key.", 0);
		goto end;
	}

#ifndef OPENSSL_NO_RSA
	if (pkey_type == TYPE_RSA) {
		if (!EVP_PKEY_assign_RSA(pkey, RSA_generate_key(newkey,0x10001, NULL,NULL))) {
			exitstr = _("Problem generating RSA key.", 0);
			goto end;
		}
	} else
#endif
#ifndef OPENSSL_NO_DSA
	if (pkey_type == TYPE_DSA) {
		if (!DSA_generate_key(dsa_params) ||
		    !EVP_PKEY_assign_DSA(pkey,dsa_params)) {
			exitstr = _("Problem generating DSA key.", 0);
			goto end;
		}
		dsa_params=NULL;
	}
#endif

/*DELRAND app_RAND_write_file(randfile, bio_err); */
	if (pkey == NULL) {
		exitstr = _("Error: Private key is blank.", 0);
		goto end;
	}

	if (BIO_write_filename(out, (char*)keyout) <= 0) {
		exitstr = _("Error assigning private output filename.", 0);
		goto end;
	}

	if (nodes) cipher=NULL;

	i=0;
loop:
	if (!PEM_write_bio_PrivateKey(out,pkey,cipher,NULL,0,NULL, (char*)passout)) {
		if ((ERR_GET_REASON(ERR_peek_error()) == PEM_R_PROBLEMS_GETTING_PASSWORD) && (i < 3)) {
			ERR_clear_error();
			i++;
			goto loop;
		}
		exitstr = _("Could not write the private key.", 0);
		goto end;
	}
	
#ifndef OPENSSL_NO_DSA
	if (pkey->type == EVP_PKEY_DSA)
		digest=EVP_dss1();
#endif
		
	req=X509_REQ_new();
	if (req == NULL) {
		exitstr = _("Problem allocating request.", 0);
		goto end;
	}

	i = make_REQ(req, pkey);

	if (kludge && !sk_X509_ATTRIBUTE_num(req->req_info->attributes)) {
		sk_X509_ATTRIBUTE_free(req->req_info->attributes);
		req->req_info->attributes = NULL;
	}

	if (!i) {
		exitstr = _("Problems generating certificate request. Please check your input.\n(Hint: No field in the Distinguished Name section may be blank.)", 0);
		goto end;
	}

	if (!(i=X509_REQ_sign(req,pkey,digest))) {
		exitstr = _("Problem signing certificate request.", 0);
		goto end;
	}

	if (strcmp(outfile, keyout) == 0)
		i=(int)BIO_append_filename(out, (char*)outfile);
	else
		i=(int)BIO_write_filename(out, (char*)outfile);
	if (!i) {
		exitstr = _("Problems assigning the output filename.", 0);
		goto end;
	}

	if (pubkey) {
		EVP_PKEY *tpubkey=X509_REQ_get_pubkey(req);

		if (tpubkey == NULL) {
			exitstr = _("Error getting public key.", 0);
			goto end;
		}
		PEM_write_bio_PUBKEY(out, tpubkey);
		EVP_PKEY_free(tpubkey);
	}

/*	if(subject) print_name(out, "subject=", X509_REQ_get_subject_name(req), nmflag);
*/
	if (!noout) {
		if (outformat == FORMAT_ASN1) i = i2d_X509_REQ_bio(out,req);
		else if (outformat == FORMAT_PEM) i = PEM_write_bio_X509_REQ(out,req);
		else {
			exitstr = _("Bad output format specified.", 0);
			goto end;
		}
		if (!i) {
			exitstr = _("Unable to write X509 request.", 0);
			goto end;
		}
	}
end:
//	if (ex) ERR_print_errors(bio_err); ///change to _fp ?
	BIO_free_all(out);
	EVP_PKEY_free(pkey);
	X509_REQ_free(req);
	OBJ_cleanup();
#ifndef OPENSSL_NO_DSA
	if (dsa_params != NULL) DSA_free(dsa_params);
#endif

	EVP_cleanup();
	CRYPTO_cleanup_all_ex_data();
	ERR_remove_state(0);
	ERR_free_strings();

	return exitstr;
}

static int add_one_value(X509_NAME *subj, const char *key, int IN_val)
{
	const char *value = DlgGetValue(IN_val);

	if (!value[0]) return 0;

	return (X509_NAME_add_entry_by_txt(subj, (char *)key, MBSTRING_ASC, (char *)value, -1, -1, 0) != 0) ? 1 : 0;
}

static int make_REQ(X509_REQ *req, EVP_PKEY *pkey)
{
	X509_NAME *subj = X509_REQ_get_subject_name(req);

	/* setup version number */
	if (!X509_REQ_set_version(req, 0L)) return 0; /* version 1 */

	if (	add_one_value(subj, "C", IN_COUNTRY) +
		add_one_value(subj, "ST", IN_STATE) +
		add_one_value(subj, "L", IN_LOCALITY) +
		add_one_value(subj, "O", IN_ORGANIZATION) +
		add_one_value(subj, "OU", IN_ORGUNIT) +
		add_one_value(subj, "CN", IN_COMMONNAME) +
		add_one_value(subj, "emailAddress", IN_EMAIL) != 7)
			return 0;
 	
	if (!X509_REQ_set_pubkey(req, pkey)) return 0;

	return 1;
}

int Str2fmt(const char *s)
{

	if (!s || !s[0]) return FORMAT_PEM;

	if 	((*s == 'D') || (*s == 'd'))
		return(FORMAT_ASN1);
	else if ((*s == 'T') || (*s == 't'))
		return(FORMAT_TEXT);
	else if ((*s == 'P') || (*s == 'p'))
		return(FORMAT_PEM);
	else if ((*s == 'N') || (*s == 'n'))
		return(FORMAT_NETSCAPE);
	else if ((*s == 'S') || (*s == 's'))
		return(FORMAT_SMIME);
	else if ((*s == '1')
		|| (strcmp(s, "PKCS12") == 0) || (strcmp(s,"pkcs12") == 0)
		|| (strcmp(s, "P12") == 0) || (strcmp(s,"p12") == 0))
		return(FORMAT_PKCS12);
	else if ((*s == 'E') || (*s == 'e'))
		return(FORMAT_ENGINE);
	else
		return(FORMAT_UNDEF);
}
