/*
 *  My Certificate Wizard
 *
 *  Copyright (C) 2004 Vlada Macek <mycert@seznam.cz>
 *
 ** $Id: customize.c,v 1.4 2004/11/17 19:37:03 tuttle Exp $ **
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <windows.h>

#include "mycert-res.h"
#include "mycert.h"

extern GLOBALS globals;

#define SAMESIZE 512

const char *_(const char *key, int bufindex)
{
	static char buf1[SAMESIZE], buf2[SAMESIZE];
	char *p, *value;
	int test1 = 0, test2 = 0;

	if (key == NULL) return NULL;

	value = bufindex ? buf2 : buf1;

	*(value + SAMESIZE - 1) = '\0';
	strlcpy(value, key, SAMESIZE-1);

	for (p=value; *p; p++)
		if (*p == '=') *p = '_';
		else if (*p == '\n') {
			*p = '^';
			test1++;
		} else if (*p == '%')
			test2++;

	GetPrivateProfileString("strings", value, key, value, SAMESIZE-1, globals.MyConfig);

	if (*value != '\0') {
		for (p=value; *p; p++)
			if (*p == '^') {
				*p = '\n';
				test1--;
			} else if (*p == '%')
				test2--;
	} else test1 = -1;

	if (test1 || test2)   /* There is a mismatch in the number of % or \n characters! */
		strlcpy(value, key, SAMESIZE-1);

	return value;
}

void customize_text(HWND h, int item)
{
	char buf[512];
	
	if (GetDlgItemText(h, item, buf, sizeof(buf)-1) == 0) return;
	buf[sizeof(buf)-1] = '\0';
	SetDlgItemText(h, item, _(buf, 0));
}

void customize_caption(HWND h)
{
	char buf[512];
	
	if (GetWindowText(h, buf, sizeof(buf)-1) == 0) return;
	buf[sizeof(buf)-1] = '\0';
	SetWindowText(h, _(buf, 0));
}

void CustomizeMainDialog(HWND h)
{
	customize_caption(h);
	customize_text(h, MSG_DN);
	customize_text(h, MSG_CN);
	customize_text(h, MSG_EMAIL);
	customize_text(h, MSG_COUNTRY);
	customize_text(h, MSG_STATE);
	customize_text(h, MSG_LOCALITY);
	customize_text(h, MSG_ORG);
	customize_text(h, MSG_OU);
	customize_text(h, MSG_PPROT);
	customize_text(h, MSG_PASS1);
	customize_text(h, MSG_PASS2);

	customize_text(h, MSG_FOLDER);
	customize_text(h, MSG_OUTPUT);
	customize_text(h, IDCHGFOLDER);
	customize_text(h, IDOK);
	customize_text(h, IDCANCEL);
	customize_text(h, TEXT_VERSION);
}
void CustomizeWaitDialog(HWND h)
{
	customize_text(h, MSG_GENERATING);	
}

void CustomizeDoneDialog(HWND h)
{
	customize_caption(h);
	customize_text(h, MSG_FILES);
	customize_text(h, MSG_STATUS);
	customize_text(h, TEXT_WARNING);
	customize_text(h, MSG_YOURREQ);
	customize_text(h, MSG_INFO);
	customize_text(h, IDOK);
	customize_text(h, IDCOPYBUT);
}
