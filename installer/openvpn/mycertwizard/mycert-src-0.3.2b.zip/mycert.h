/*
 *  My Certificate Wizard
 *
 *  Copyright (C) 2004 Vlada Macek <mycert@seznam.cz>
 *
 ** $Id: mycert.h,v 1.11 2004/11/17 19:37:03 tuttle Exp $ **
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#define VERSION "0.3.2b"

/* The text displayed by the About dialog (icon button) */

#define ABOUTTEXT "My Certificate Wizard\nVersion %s\n\nhttp://www.sweb.cz/mycert\n\n(c) 2004 Vlada Macek\nReleased under the terms of GNU General Public License.\nhttp://www.gnu.org\n\nThe development was funded by Hieronymus,\ntranslation and software localization company.\nhttp://www.hiero.cz/us"

#define MAXLINELEN 128
#define BUFLEN     512
#define MINPASSLEN 4

/* Filename extensions. */

#define KEY_EXT "key"
#define REQ_EXT "req"
#define CERT_EXT "cert"
#define OVPN_EXT "ovpn"

typedef struct {
	char MyConfig[MAX_PATH+1];
	char KeyFilePath[MAX_PATH+1];
	char OutFilePath[MAX_PATH+1];
	char CertFilePath[MAX_PATH+1];
	char OVPNTemplate[MAX_PATH+1];
	char OVPNFilePath[MAX_PATH+1];
	char OutFolder[MAX_PATH+1];
	char KeyExt[16], CertExt[16], ReqExt[16], OvpnExt[16];
	BOOL cfg_nodes;
	const char *opensslerr;
	char msgbuf[50*1024];
	HWND myH;
	HINSTANCE myI;
} GLOBALS;

/* request.c */
const char *CreateRequest(const char *keyout, const char *outfile, int nodes, const char *passout);

/* misc.c */

size_t strlcpy(char *dst, const char *src, size_t siz);
size_t strlcat(char *dst, const char *src, size_t siz);
int vslprintf(char *str, size_t n, const char *format, va_list ap) __attribute__((format(printf, 3, 0)));
int slprintf(char *str, size_t n, const char *format, ...) __attribute__((format(printf, 3, 4)));

int Atoi(const char *str);

const char *CfgGetValue(const char *key);
const char *DlgGetValue(int key);
void safe_string(char *cp);
void ErrorExit(const char *funcname) __attribute__((noreturn));
BOOL CopyExtraFiles(void);
void DestroyBillGatesEmpire(void);
BOOL ChooseFolder(HWND owner, char *pszDir);
BOOL CALLBACK DONEDialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL ProcessOVPNTemplate(void);
void ResolveConfigFilename(const char *forcepath);

#ifdef REGULAR_EXPRESSIONS
BOOL RegExpMatch(const char *regexp, const char *matchstring);
#endif

/* customize.c */
const char *_(const char *key, int bufindex);
void CustomizeMainDialog(HWND hwndDlg);
void CustomizeWaitDialog(HWND hwndDlg);
void CustomizeDoneDialog(HWND hwndDlg);


/* *** */

/* shorthands */
#define sLprintf(str, args...)	slprintf(str, sizeof(str)-1, args)
#define strLcat(dst, src)	strlcat(dst, src, sizeof(dst))
#define strLcpy(dst, src)	strlcpy(dst, src, sizeof(dst))

/* universal message box */
#define MsgBox(caption, options, args...) MessageBox(globals.myH, (sLprintf(globals.msgbuf, args), globals.msgbuf), caption, options)
