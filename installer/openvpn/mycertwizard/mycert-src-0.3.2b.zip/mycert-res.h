
#define	APP_ICON	90
#define	DLG_MYCERT	100
#define	IDCHGFOLDER	104
#define	IN_COUNTRY	115
#define	IN_STATE	116
#define	IN_LOCALITY	117
#define	IN_ORGANIZATION	118
#define	IN_ORGUNIT	119
#define	IN_COMMONNAME	120
#define	IN_EMAIL	121
#define	IN_PASS		122
#define	IN_PASS2	123
#define	IN_FOLDER	124

#define	TEXT_FOLDER	126
#define	IDHELPBUT	127
#define	TEXT_VERSION	128
#define IDABOUTBUT	129

#define	DLG_DONE	200
#define	TEXT_PATH	203
#define	TEXT_DONEMSG	204
#define	IDCOPYBUT	208
#define	TEXT_WARNING	209

#define	DLG_PLSWAIT	300

#define MSG_DN	150
#define MSG_CN	151
#define MSG_EMAIL	152
#define MSG_COUNTRY	153
#define MSG_STATE	154
#define MSG_LOCALITY	155
#define MSG_ORG	156
#define MSG_OU	157
#define MSG_PPROT	158
#define MSG_PASS1	159
#define MSG_PASS2	160
#define MSG_FOLDER	161
#define MSG_OUTPUT	162

#define MSG_FILES	163
#define MSG_STATUS	164
#define MSG_YOURREQ	165
#define MSG_INFO	166

#define MSG_GENERATING	167
