/*
 *  My Certificate Wizard
 *
 *  Copyright (C) 2004 Vlada Macek <mycert@seznam.cz>
 *
 ** $Id: misc.c,v 1.10 2004/11/17 19:37:03 tuttle Exp $ **
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (see the file COPYING included with this
 *  distribution); if not, write to the Free Software Foundation, Inc.,
 *  59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <shlobj.h>
#include <string.h>
#include <unistd.h>
#include <windows.h>
#include <stdarg.h>
#include <sys/types.h>

#ifdef REGULAR_EXPRESSIONS
#	include <regex.h>
#endif

#include "mycert-res.h"
#include "mycert.h"

extern GLOBALS globals;

/* Four borrowed functions: strlcpy, strlcat, printf's */

/*
 * Copy src to string dst of size siz.  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz == 0).
 * Returns strlen(src); if retval >= siz, truncation occurred.
 */
size_t strlcpy(char *dst, const char *src, size_t siz)
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;

	/* Copy as many bytes as will fit */
	if (n != 0 && --n != 0) {
		do {
			if ((*d++ = *s++) == 0) break;
		} while (--n != 0);
	}

	/* Not enough room in dst, add NUL and traverse rest of src */
	if (n == 0) {
		if (siz != 0) *d = '\0';	/* NUL-terminate dst */
		while (*s++) ;
	}

	return(s - src - 1);	/* count does not include NUL */
}

/*
 * Appends src to string dst of size siz (unlike strncat, siz is the
 * full size of dst, not space left).  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz <= strlen(dst)).
 * Returns strlen(src) + MIN(siz, strlen(initial dst)).
 * If retval >= siz, truncation occurred.
 */
size_t strlcat(char *dst, const char *src, size_t siz)
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;
	size_t dlen;

	/* Find the end of dst and adjust bytes left but don't go past end */
	while (n-- != 0 && *d != '\0') d++;
	dlen = d - dst;
	n = siz - dlen;

	if (n == 0) return (dlen + strlen(s));
	while (*s != '\0') {
		if (n != 1) {
			*d++ = *s;
			n--;
		}
		s++;
	}
	*d = '\0';

	return(dlen + (s - src));	/* count does not include NUL */
}


/* this is like vsnprintf but the 'n' limit does not include
   the terminating null. So if you have a 1024 byte buffer then
   pass 1023 for n */
int vslprintf(char *str, size_t n, const char *format, va_list ap)
{
	int ret = vsnprintf(str, n, format, ap);
	if ((ret > (int)n) || (ret < 0)) {
		str[n] = 0;
		return -1;
	}
	str[ret] = 0;
	return ret;
}

int slprintf(char *str, size_t n, const char *format, ...)
{
	va_list ap;  
	int ret;

	va_start(ap, format);
	ret = vslprintf(str, n, format, ap);
	va_end(ap);
	return ret;
}

int Atoi(const char *str)
{
	if ((str == NULL) || (*str == '\0')) return 0;
	return atoi(str);
}

/* Two request.c "callbacks". */
const char *CfgGetValue(const char *key)
{
	static char value[MAXLINELEN+1];

	GetPrivateProfileString("openssl", key, NULL, value, sizeof(value), globals.MyConfig);
	value[sizeof(value)-1] = '\0';

#ifdef DEBUG
	printf("cfggetvalue: %s -> %s\n", key, value ? value : "(null)");
	fflush(stdout);
#endif
	return value;
}

const char *DlgGetValue(int key)
{
	static char value[MAXLINELEN+1];

	GetDlgItemText(globals.myH, key, value, sizeof(value));
	value[sizeof(value)-1] = '\0';

#ifdef DEBUG
	printf("dlggetvalue: %d -> %s\n", key, value ? value : "(null)");
	fflush(stdout);
#endif
	return value;
}

/* make the string safe to be passed somewhere */
void safe_string(char *cp)
{
	int c;
	while ((c = *cp)) {
		if (((c >= 'a') && (c <= 'z')) || ((c >= 'A') && (c <= 'Z')) ||
			((c >= '0') && (c <= '9')) || c == '-') ;
		else *cp = '_';

		++cp;
	}
}

/* show the Last Error in message box then exit the application with an error */
void ErrorExit(const char *funcname)
{ 
	LPVOID lpMsgBuf;
	DWORD dw = GetLastError(); 

	FormatMessage(
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM,
		NULL,
		dw,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
		(LPTSTR) &lpMsgBuf,
		0, NULL);

	MsgBox(_("Fatal Error", 0), MB_OK | MB_ICONERROR, _("Function %s failed with error %d: %s", 1),
		funcname, (int)dw, (char *)lpMsgBuf); 

	LocalFree(lpMsgBuf);
	ExitProcess(dw); 
}

void DestroyBillGatesEmpire()
{
	/* To be implemented. */
}

int CALLBACK _ChooseFolderFunc(HWND hWnd, UINT uMsg, LPARAM lParam __attribute__((unused)), LPARAM lpData)
{
	if (uMsg==BFFM_INITIALIZED)
		SendMessage(hWnd, BFFM_SETSELECTION, TRUE, lpData);

	return 0;
}

BOOL ChooseFolder(HWND owner, char *pszDir)
{
	BROWSEINFO bi;
	LPITEMIDLIST pidlBrowse;

	bi.hwndOwner = owner;
	bi.pidlRoot = NULL;
	bi.lpszTitle = _("Please select the folder where your new private key and request shall be saved:", 0);
	bi.pszDisplayName = pszDir;
	bi.ulFlags = BIF_RETURNONLYFSDIRS;
	bi.lpfn = _ChooseFolderFunc;
	bi.lParam = (LPARAM)(LPCSTR)pszDir;

	pidlBrowse = SHBrowseForFolder(&bi);
	if (pidlBrowse && SHGetPathFromIDList(pidlBrowse, pszDir))
		return TRUE;
	return FALSE;
} 

BOOL CALLBACK DONEDialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam __attribute__((unused)))
{
  HICON hIcon;
  RECT rect;
  FILE *fp;
  LOGFONT logFont;
  HFONT hFont;
  char *p;

  switch (msg) {

    case WM_INITDIALOG:
    
    CustomizeDoneDialog(hwndDlg);
    
	hIcon = (HICON)LoadImage(GetModuleHandle(NULL),
		MAKEINTRESOURCE(APP_ICON), IMAGE_ICON, 0, 0, LR_DEFAULTCOLOR);
	if (hIcon) {
		SendMessage(hwndDlg, WM_SETICON, (WPARAM) (ICON_SMALL), (LPARAM) (hIcon));
		SendMessage(hwndDlg, WM_SETICON, (WPARAM) (ICON_BIG), (LPARAM) (hIcon));
	}

	GetWindowRect(hwndDlg, &rect);
	MoveWindow(hwndDlg,	rect.left,
				rect.top + 100,
				rect.right - rect.left,
				rect.bottom - rect.top, FALSE);

	SetDlgItemText(hwndDlg, TEXT_PATH, globals.msgbuf);

	GetObject(GetStockObject(DEFAULT_GUI_FONT), sizeof(logFont), &logFont);
 	logFont.lfWeight = FW_BOLD;
  	hFont = CreateFontIndirect(&logFont);
	SendDlgItemMessage(hwndDlg, TEXT_WARNING, WM_SETFONT, (WPARAM)hFont, 0);

	GetObject(GetStockObject(DEFAULT_GUI_FONT), sizeof(logFont), &logFont);
 	strLcpy(logFont.lfFaceName, TEXT("Fixedsys"));
  	hFont = CreateFontIndirect(&logFont);
	/* I don't know where to destroy this font and whether it is neccessary. */

	sLprintf(globals.msgbuf, _("Filename: %s", 0), globals.OutFilePath);
	strLcat(globals.msgbuf, "\r\n");
	p = globals.msgbuf + strlen(globals.msgbuf);

	fp = fopen(globals.OutFilePath, "r");
	if (fp) {
		char *e = globals.msgbuf + sizeof(globals.msgbuf);

		/* Read and convert LF -> CRLF */
		while(fgets(p, e - p, fp)) {
			if ((p = strchr(p, '\n'))) {
				*p++ = '\r';
				*p++ = '\n';
				if (p >= e) break;
			} else break;
		}
		globals.msgbuf[sizeof(globals.msgbuf)-1] = '\0';
		fclose(fp);

		SendDlgItemMessage(hwndDlg, TEXT_DONEMSG, WM_SETFONT, (WPARAM)hFont, 0);
		SetDlgItemText(hwndDlg, TEXT_DONEMSG, globals.msgbuf);

	} else SetDlgItemText(hwndDlg, TEXT_DONEMSG, _("(Cannot read the file.)", 0));

	return TRUE;

    case WM_COMMAND:
	switch (LOWORD(wParam)) {
	    case IDOK:
          	EndDialog(hwndDlg, LOWORD(wParam));
		return TRUE;
	    case IDCOPYBUT:
		SendDlgItemMessage(hwndDlg, TEXT_DONEMSG, EM_SETSEL, 0, -1);
		SendDlgItemMessage(hwndDlg, TEXT_DONEMSG, WM_COPY, 0, 0);
		return TRUE;
            case IDCANCEL:
		EndDialog(hwndDlg, LOWORD(wParam));
		return TRUE;
	}
	break;
    case WM_CLOSE:
	EndDialog(hwndDlg, LOWORD(wParam));
	return TRUE;   
  }
  return FALSE;
}

static BOOL CopyOneFile(const char *source, const char *target)
{
	if(!CopyFile(source, target, FALSE)) {
		char buffer[BUFLEN+1], *lpMsgBuf = NULL;
		DWORD errorCode = GetLastError();

		FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_ALLOCATE_BUFFER,
			      NULL, errorCode, 0, (char*)&lpMsgBuf, 0, NULL);
    
		sLprintf(buffer, _("Unable to copy '%s' to '%s' - error %d", 0), source, target, errorCode);

		MsgBox(_("Failure copying files", 0), MB_OK, "%s: %s", buffer, lpMsgBuf);
		LocalFree(lpMsgBuf);

		return FALSE;
	}
	return TRUE;
}

static BOOL CopyFileToOutDir(const char *filename)
{
	char target[MAX_PATH+1];
	const char *basename = strrchr(filename, '\\');

	if (!basename) basename = filename;
	while (basename[0] == '\\') basename++;

	strLcpy(target, globals.OutFolder);
	strLcat(target, "\\");
	strLcat(target, basename);

	return CopyOneFile(filename, target);
}

BOOL CopyExtraFiles()
{
	char CopyFiles[10*MAX_PATH];
	char *pos, *end;
	BOOL success = TRUE;

	GetPrivateProfileString("paths", "copyfiles", "", CopyFiles, sizeof(CopyFiles), globals.MyConfig);
	if (!CopyFiles[0]) return FALSE;

	pos = CopyFiles;
	while(1) {
		end = strchr(pos, ',');
		if (!end) {
			if (pos[0] && !CopyFileToOutDir(pos))
				success = FALSE;
			break;
		}

		*end = 0;    
		if (!CopyFileToOutDir(pos)) success = FALSE;
		pos = end + 1;
	}
	return success;
}

static void escapeBackSlashes(int outBufLen, char *outBuffer, const char *inString)
{
	const char *inPos = inString;
	char *outPos = outBuffer,
	     *outEnd = outBuffer + outBufLen - 1;

	while(*inPos != 0 && outPos < outEnd) {
		if(*inPos != '\\') {
			*outPos++ = *inPos++;
		} else {
			*outPos++ = *inPos++;
			*outPos++ = '\\';
		}
	}
	*outPos++ = 0;
}

BOOL ProcessOVPNTemplate()
{
	BOOL success;
	
	success = CopyOneFile(globals.OVPNTemplate, globals.OVPNFilePath);

	if (success) {
		FILE *fp = fopen(globals.OVPNFilePath, "a");

		if (fp) {
			char keyFilePath[MAX_PATH+1], certFilePath[MAX_PATH+1];

			escapeBackSlashes(MAX_PATH, keyFilePath, globals.KeyFilePath);
			escapeBackSlashes(MAX_PATH, certFilePath, globals.CertFilePath);

			fprintf(fp, "\n\n### ");
			fprintf(fp, _("The following lines were added by the My Certificate Wizard.", 0));
			fprintf(fp, "\nkey  \"%s\"\ncert \"%s\"\n### ---\n\n", keyFilePath , certFilePath);
			fclose(fp);
		} else
			success = FALSE;
	}

	return success;
}

void ResolveConfigFilename(const char *forcepath)
{
	char *p;

	if (forcepath && forcepath[0])
		strLcpy(globals.MyConfig, forcepath);
	else {
		if (!GetModuleFileName(NULL, globals.MyConfig, MAX_PATH))
			ErrorExit("GetModuleFileName");

		p = strrchr(globals.MyConfig, '.');
		if (p) *p = '\0';
		strLcat(globals.MyConfig, ".ini");
	}

	if (access(globals.MyConfig, R_OK) != 0) {
		MsgBox("Warning", MB_OK | MB_ICONWARNING,
			"Expected INI file %s not found or is not readable. Using default values.", globals.MyConfig);
	}
}

#ifdef REGULAR_EXPRESSIONS

BOOL RegExpMatch(const char *regexp, const char *matchstring)
{
	regex_t re;
	int rc;
	char errstr[1024];

	rc = regcomp(&re, regexp, REG_EXTENDED | REG_NOSUB);
	if (rc) {
		regerror(rc, &re, errstr, sizeof(errstr)-1);
		errstr[sizeof(errstr)-1] = '\0';
		MsgBox(_("Regular expression error", 0), MB_OK | MB_ICONSTOP,
			_("Cursor will be moved to the field for which the regular expression\ncompilation have failed with the following error:\n%s", 1), errstr);

		regfree(&re);
		return FALSE;
	}

	rc = regexec(&re, matchstring, 0, NULL, 0);
	if (rc == REG_NOMATCH) {
		MsgBox(_("Input error", 0), MB_OK | MB_ICONSTOP,
			_("Cursor will be moved to the field that\nappears to be in an unallowed form.\nPlease correct your input.", 1), errstr);

		regfree(&re);
		return FALSE;
	}
	if (rc) {
		regerror(rc, &re, errstr, sizeof(errstr)-1);
		errstr[sizeof(errstr)-1] = '\0';
		MsgBox(_("Regular expression error", 0), MB_OK | MB_ICONSTOP,
			_("Cursor will be moved to the field for which the regular expression\nmatching have failed with the following error:\n%s", 1), errstr);

		regfree(&re);
		return FALSE;
	}

	regfree(&re);
	return TRUE;
}

#endif /* REGULAR_EXPRESSIONS */
